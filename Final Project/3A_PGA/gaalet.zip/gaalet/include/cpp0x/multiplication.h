#ifndef __GAALET_MULTIPLICATION_H
#define __GAALET_MULTIPLICATION_H

#include "geometric_product.h"
#include "inner_product.h"
#include "outer_product.h"

#endif
