#ifdef __GXX_EXPERIMENTAL_CXX0X__
   #include "cpp0x/gaalet.h"
#else
   #include "cpp/gaalet.h"
#endif
